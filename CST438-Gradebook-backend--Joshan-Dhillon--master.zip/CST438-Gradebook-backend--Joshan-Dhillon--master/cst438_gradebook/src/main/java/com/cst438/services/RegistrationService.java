package com.cst438.services;

import com.cst438.domain.CourseDTOG;

public class RegistrationService {
	
	public void sendFinalGrades(int course_id , CourseDTOG courseDTO) {
		
	}

}
